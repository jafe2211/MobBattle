package de.jafe2211.mobbattle.Utility;

public class EntityKilled {
    public static String name;
    public static int Count;

    public EntityKilled(String newName, int newCount){
        name = newName;
        Count = newCount;
    }
}
