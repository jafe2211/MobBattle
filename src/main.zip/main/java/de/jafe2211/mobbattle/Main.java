package de.jafe2211.mobbattle;

import de.jafe2211.mobbattle.Commands.test;
import de.jafe2211.mobbattle.Listeners.Chat;
import de.jafe2211.mobbattle.Listeners.JoinLeve;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin {

    @Override
    public void onEnable() {
        System.out.println("");
        System.out.println("╔═══════════════════════════╗");
        System.out.println("║         Mob Battle        ║");
        System.out.println("╠═══════════════════════════╣");
        System.out.println("║  Plugin made by Jafe2211  ║");
        System.out.println("║        Version: 1.0       ║");
        System.out.println("╚═══════════════════════════╝");
        System.out.println("");
        loadEvents();
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }

    public static String prefix(){
        return ChatColor.GRAY + "[" + ChatColor.AQUA + "" + ChatColor.BOLD + "MobBattle" + ChatColor.GRAY + "]";
    }

    public void loadEvents(){
        Bukkit.getPluginManager().registerEvents(new JoinLeve(), this);
        Bukkit.getPluginManager().registerEvents(new Chat(), this);
        this.getCommand("1234").setExecutor(new test());
    }
}
