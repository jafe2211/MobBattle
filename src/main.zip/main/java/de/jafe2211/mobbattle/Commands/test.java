package de.jafe2211.mobbattle.Commands;

import de.jafe2211.mobbattle.Utility.EntityKilled;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;

public class test implements CommandExecutor {

    ArrayList<EntityKilled> entityKilleds = new ArrayList();
    @Override
    public boolean onCommand(CommandSender cs, Command command, String s, String[] strings) {
        Player p = (Player)cs;

        for (EntityType entity : EntityType.values()) {
            try {
                if (p.getStatistic(Statistic.KILL_ENTITY, entity) != 0) {
                    cs.sendMessage(String.valueOf(entity + " " + String.valueOf(p.getStatistic(Statistic.KILL_ENTITY, entity))));

                    EntityKilled entity1 = new EntityKilled(String.valueOf(entity), p.getStatistic(Statistic.KILL_ENTITY, entity));
                    entityKilleds.add(entity1);
                }
            } catch (Exception ignored){

            }

        }

       cs.sendMessage(String.valueOf(entityKilleds));
        return false;
    }
}
