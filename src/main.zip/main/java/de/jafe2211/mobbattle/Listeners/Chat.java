package de.jafe2211.mobbattle.Listeners;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class Chat implements Listener {

    @EventHandler
    public void onChatMessage(AsyncPlayerChatEvent e){
        String message = e.getMessage();
        message = message.replace("&", "$");
        message = message.replace("%","%%");

        if (e.getPlayer().isOp()){
            e.setFormat("" +ChatColor.DARK_GRAY + "[" + ChatColor.DARK_RED + ChatColor.BOLD + "Admin" + ChatColor.DARK_GRAY + "] "+ ChatColor.BOLD + ChatColor.GOLD + e.getPlayer().getName() + ChatColor.RESET + ChatColor.DARK_GRAY + " | " + ChatColor.DARK_AQUA+ ChatColor.BOLD + message);
        } else{
            e.setFormat("" + ChatColor.GOLD + e.getPlayer().getName() + ChatColor.DARK_GRAY + " | " + ChatColor.WHITE + message);
        }

    }
}
